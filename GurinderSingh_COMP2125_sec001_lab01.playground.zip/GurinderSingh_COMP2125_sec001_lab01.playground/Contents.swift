import Cocoa

var str = "Hello, playground"

// Example 01
// declaring a function to swap two numbers.
func swap<T>(a: inout T, b: inout T){
    var c = a;
    a = b;
    b = c;
}

// testing the functionality using integer data type
    var num1 = 2;
    var num2 = 4;
    swap(&num1, &num2);
    print("num1: ", num1);
    print("num2: ", num2);

// testing the functionality using string data type

    var str1 = "Gurinder";
    var str2 = "Singh";
    swap(&str1, &str2);
    print("str1: ", str1);
    print("str2: ", str2);

// testing the functionality using double data type

    var dbl1 = 2.02;
    var dbl2 = 4.04;
    swap(&dbl1, &dbl2);
    print("dbl1: ", dbl1);
    print("dbl2: ", dbl2, "\n");

// Exampme 02
// declaring a function named SunAvgArray to calculate the submission and average of the arrray initialized
func SumAvgArray(values: [Int]) -> (Int,Double){
    var sum: Int  = 0;
    var avg: Double = 0.0;
    for val in values {
        sum += Int(val)
        avg = Double(sum) / Double(values.count);
        }
    return (sum, avg);
}
// checking the functionality of the function
let array = [1,2,3,4,5,1];
print ("Sum and average of the array is: ")
print(SumAvgArray(values: array), "\n");

// Example 03

// Key as string and value as an array
let tempReadings = [
    "Monday": [12,25,10],
     "Tuesday" : [2, 15, 9],
     "Wednesday" : [11, 29, 22],
     "Thursday" : [7, 11, 9],
     "Friday" : [ 16, 22, 20]
]
// declaring variables to work with such as sum(total of temperature for a day), average etc.
var sum: Double ;
var avg : Double = 0.0;
var weekTotal: Double = 0.0;
var weekCount: Int = 0;

// executingn the loop to get into the dictionary

for (day, temperature) in tempReadings{
      sum = 0.0;
    // loop to work with the [Int]
    for temp in temperature{
    sum += Double(temp);
    }
// a
print("average temperature of \(day): " +
String (format: "%.2f", sum / Double(temperature.count)))
    
// c
print("Maximum Temperature of the \(day): ", temperature.max()!, "\n");
    
    weekTotal += Double(sum);
    weekCount += Int(temperature.count);// String formating
}
// b
print("average temperature of week: " +
String (format: "%.2f", Double(weekTotal) / Double(weekCount)), "\n");


// example 4

var stockValues = [30.50, 10.25, 60.75, 100.25, 45.45, 89.60, 20.50, 55.55, 90.0, 70.0];

// a
func ModifyStockValues(values: inout [Double]){
    for i in 0 ..< values.count{
        values[i] += 10.00;
    }
}
print("Original Array: " + stockValues.description)
ModifyStockValues(values: &stockValues)
print("Modified Array: " + stockValues.description, "\n");

// b
func ModifyStockElements(element: inout Double){
    element += 10.00;
}
print("Original Element: \(stockValues[0])")
ModifyStockElements(element: &stockValues[0]);
print("Modified Element: \(stockValues)")
